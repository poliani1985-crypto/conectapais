import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import './style.css';

const CONFIG = {
  nomeProduto: 'ConectaPais: Laços Educativos entre Família e Escola',
  instituicao: 'CMEI João Paulo II',
  pesquisadora: 'Poliani Cristina Fratoni de Oliveira',
  orientador: 'Prof. Dr. David da Silva Pereira',
  emailContato: 'profpoli26@gmail.com',
  telefoneContato: '(43) 98442-7704',
  linksGoogleForms: {
    paisInicial: '',
    paisFinal: '',
    equipeInicial: '',
    equipeFinal: '',
    enqueteFinal: ''
  },
  conteudosSemana: [
    {titulo:'O brincar também ensina', tipo:'Texto + imagem', emoji:'🧸', texto:'Na Educação Infantil, brincar é uma forma importante de aprender. Enquanto brinca, a criança imagina, conversa, cria regras, resolve problemas, expressa sentimentos e desenvolve diferentes habilidades. Por isso, o brincar no CMEI não é apenas passatempo, mas parte do trabalho pedagógico planejado.'},
    {titulo:'Cuidar e educar caminham juntos', tipo:'Texto curto', emoji:'💛', texto:'Na Educação Infantil, cuidar e educar acontecem juntos. Os momentos de alimentação, higiene, descanso, brincadeiras e rodas de conversa também ensinam. Neles, a criança aprende autonomia, convivência, linguagem, respeito e segurança emocional.'},
    {titulo:'A rotina do CMEI tem aprendizagem', tipo:'Vídeo curto', emoji:'🎬', texto:'A rotina ajuda a criança a se sentir segura e compreender os momentos do dia. Cada atividade possui uma intenção: acolhida, alimentação, brincadeiras, histórias, músicas, atividades dirigidas e momentos de descanso fazem parte do desenvolvimento integral.'},
    {titulo:'Como a família pode participar?', tipo:'Orientação prática', emoji:'👨‍👩‍👧', texto:'A família pode participar acompanhando os comunicados, conversando com a criança sobre o que vive no CMEI, participando das reuniões quando possível, enviando dúvidas e valorizando as experiências pedagógicas compartilhadas pela escola.'},
    {titulo:'Registro pedagógico da semana', tipo:'Imagem informativa', emoji:'🌈', texto:'Este espaço pode ser usado semanalmente para apresentar um registro pedagógico, uma imagem informativa, uma proposta realizada com as crianças ou um pequeno recado explicando às famílias o objetivo de determinada atividade.'}
  ],
  conteudosAnteriores: ['Semana 1: Conhecendo o ConectaPais','Semana 2: O papel da Educação Infantil','Semana 3: Família e escola juntas','Semana 4: Aprendizagens no cotidiano']
};

const TCLE = {
  pais: 'Você está sendo convidado(a) a participar desta pesquisa de forma livre e voluntária. Esta pesquisa será desenvolvida no contexto da Educação Infantil e busca compreender de que maneira a aproximação entre famílias e equipe pedagógica pode ser fortalecida. O produto educacional digital ConectaPais terá conteúdos informativos em linguagem simples, imagens, vídeos curtos, informações sobre a rotina escolar, orientações pedagógicas e espaço para diálogo e dúvidas. A participação é voluntária, você pode deixar de responder qualquer pergunta e pode desistir a qualquer momento, sem prejuízo para você, sua criança ou sua relação com a instituição.',
  equipe: 'Você está sendo convidado(a) a participar desta pesquisa de forma livre e voluntária. A pesquisa busca compreender de que maneira a relação entre famílias e equipe pedagógica pode ser fortalecida por meio de práticas de comunicação, diálogo e aproximação. Sua participação poderá envolver acompanhamento do produto educacional, apoio institucional, orientações pedagógicas, colaboração em relação aos conteúdos e respostas aos questionários inicial e final. Você pode desistir em qualquer etapa, sem prejuízo profissional ou institucional.'
};

const forms = {
 paisInicial: {
  titulo:'Questionário inicial — Famílias / Pais / Responsáveis', codigo:'2 primeiras letras do nome da criança + 2 dígitos da idade da criança. Exemplo: Maria, 4 anos = MA04.',
  objetivas:[
   ['Por qual motivo principal você matriculou seu filho(a) no CMEI?',['Preciso trabalhar e não tenho com quem deixar','Quero que meu filho(a) se desenvolva integralmente','Outro motivo diferente das opções acima','Prefiro não responder']],
   ['Na sua opinião, qual é a principal função do CMEI?',['Cuidar da criança enquanto a família trabalha','Ensinar, cuidar e contribuir no desenvolvimento da criança','Apenas preparar para o Ensino Fundamental','Prefiro não responder']],
   ['Você acredita que seu filho(a) aprende no CMEI?',['Sim, aprende bastante','Aprende algumas coisas','Aprende pouco ou nada','Prefiro não responder']],
   ['Você sente que conhece o trabalho realizado pelos professores no CMEI?',['Sim, conheço bem','Conheço um pouco','Conheço muito pouco','Prefiro não responder']],
   ['A escola costuma explicar o que a criança aprende no dia a dia?',['Sempre','Às vezes','Nunca ou quase nunca','Prefiro não responder']],
   ['Como você avalia a comunicação entre sua família e o CMEI?',['Muito boa','Boa','Precisa melhorar','Prefiro não responder']],
   ['Você participa das atividades propostas pela escola quando possível?',['Sempre','Às vezes','Raramente','Prefiro não responder']],
   ['Você acredita que a participação da família ajuda no desenvolvimento da criança?',['Sim, ajuda muito','Ajuda um pouco','Não faz diferença','Prefiro não responder']],
   ['Você gostaria de receber mais informações sobre o trabalho pedagógico do CMEI?',['Sim, gostaria muito','Gostaria um pouco','Não tenho interesse','Prefiro não responder']],
   ['Você acredita que escola e família devem trabalhar juntas?',['Sim, sempre','Em alguns momentos','Não considero necessário','Prefiro não responder']]
  ], abertas:['O que você considera mais importante no trabalho realizado pelo CMEI?','Na sua opinião, o que poderia melhorar na relação entre família e escola?','Deixe uma opinião, sugestão ou comentário sobre o CMEI.']},
 paisFinal: {titulo:'Questionário final — Famílias / Pais / Responsáveis', codigo:'Use o mesmo código criado no início da pesquisa.', objetivas:[
  ['Após sua participação na pesquisa, como você compreende hoje a função do CMEI?',['Apenas local de cuidado','Espaço de cuidado, ensino e desenvolvimento integral','Ainda tenho dúvidas sobre sua função','Prefiro não responder']],
  ['Hoje você acredita que seu filho(a) aprende no CMEI?',['Sim, aprende bastante','Aprende algumas coisas','Aprende pouco ou nada','Prefiro não responder']],
  ['Atualmente você sente que conhece melhor o trabalho realizado pelos professores?',['Sim, conheço melhor','Conheço um pouco melhor','Não percebi mudança','Prefiro não responder']],
  ['Depois da participação no projeto, como você avalia a comunicação entre família e CMEI?',['Melhorou bastante','Melhorou um pouco','Não mudou','Prefiro não responder']],
  ['Hoje a escola explica melhor o que a criança aprende no dia a dia?',['Sempre','Às vezes','Não percebi mudança','Prefiro não responder']],
  ['Sua participação nas atividades e informações da escola mudou durante esse período?',['Aumentou bastante','Aumentou um pouco','Não mudou','Prefiro não responder']],
  ['Hoje você considera mais importante a participação da família no desenvolvimento da criança?',['Sim, muito mais','Sim, um pouco mais','Continuo pensando igual antes','Prefiro não responder']],
  ['Os conteúdos do ConectaPais ajudaram a compreender melhor a Educação Infantil?',['Ajudaram muito','Ajudaram um pouco','Não ajudaram','Prefiro não responder']],
  ['Você gostaria que ações como essa continuassem no CMEI?',['Sim, com certeza','Sim, em alguns momentos','Não tenho interesse','Prefiro não responder']],
  ['Hoje você acredita mais que escola e família devem trabalhar juntas?',['Sim, muito mais','Sim, continuo acreditando','Não percebi diferença','Prefiro não responder']]
 ], abertas:['O que você aprendeu ou passou a perceber melhor sobre o CMEI durante a pesquisa?','Na sua opinião, o que mudou na relação entre sua família e a escola nesse período?','Deixe sua opinião sobre o produto ConectaPais e sugestões futuras.']},
 equipeInicial: {titulo:'Questionário inicial — Equipe pedagógica', codigo:'2 primeiras letras do seu nome + 2 dígitos da sua idade. Exemplo: Maria, 40 anos = MA40.', objetivas:[
  ['Como você avalia atualmente a participação das famílias na rotina escolar do CMEI?',['Muito participativa','Participativa em alguns momentos','Pouco participativa','Prefiro não responder']],
  ['Na sua opinião, as famílias compreendem a função pedagógica da Educação Infantil?',['Compreendem bem','Compreendem parcialmente','Compreendem pouco','Prefiro não responder']],
  ['Como você avalia a comunicação entre escola e famílias?',['Muito boa','Boa','Precisa melhorar','Prefiro não responder']],
  ['Você considera importante aproximar mais as famílias do trabalho pedagógico realizado no CMEI?',['Sim, muito importante','Importante em alguns aspectos','Pouco importante','Prefiro não responder']],
  ['Você acredita que as famílias valorizam o trabalho desenvolvido pela equipe escolar?',['Sim, valorizam bastante','Valorizam parcialmente','Valorizam pouco','Prefiro não responder']],
  ['A escola já oferece meios suficientes para diálogo com as famílias?',['Sim, plenamente','Em parte','Ainda são insuficientes','Prefiro não responder']],
  ['Você teria interesse em participar de ações que fortaleçam a relação família-escola?',['Sim, muito interesse','Algum interesse','Pouco interesse','Prefiro não responder']],
  ['Você acredita que recursos digitais podem ajudar na aproximação com as famílias?',['Sim, ajudam muito','Ajudam em parte','Ajudam pouco ou nada','Prefiro não responder']],
  ['Como você percebe o envolvimento das famílias no desenvolvimento das crianças?',['Muito positivo','Parcialmente positivo','Ainda limitado','Prefiro não responder']],
  ['Você considera importante que escola e família atuem juntas no processo educativo?',['Sim, sempre','Em alguns momentos','Não considero necessário','Prefiro não responder']]
 ], abertas:['Na sua opinião, qual é o maior desafio na relação entre escola e famílias?','O que poderia melhorar na comunicação entre equipe escolar e responsáveis?','Deixe uma opinião, sugestão ou comentário sobre esse tema.']},
 equipeFinal: {titulo:'Questionário final — Equipe pedagógica', codigo:'Use o mesmo código criado no início da pesquisa.', objetivas:[
  ['Após o período da pesquisa, como você avalia atualmente a participação das famílias na rotina escolar do CMEI?',['Melhorou bastante','Melhorou um pouco','Não percebi mudança','Prefiro não responder']],
  ['Na sua opinião, as famílias compreendem melhor a função pedagógica da Educação Infantil após esse período?',['Sim, compreenderam melhor','Houve pequena melhora','Não percebi mudança','Prefiro não responder']],
  ['Como você avalia hoje a comunicação entre escola e famílias?',['Melhorou bastante','Melhorou um pouco','Não mudou','Prefiro não responder']],
  ['O produto educacional contribuiu para aproximar as famílias do trabalho pedagógico?',['Contribuiu muito','Contribuiu um pouco','Não contribuiu','Prefiro não responder']],
  ['Você percebe maior valorização das famílias em relação ao trabalho da equipe escolar?',['Sim, claramente','Em parte','Não percebi mudança','Prefiro não responder']],
  ['Os meios de diálogo entre escola e famílias melhoraram nesse período?',['Melhoraram bastante','Melhoraram um pouco','Não mudaram','Prefiro não responder']],
  ['Sua percepção sobre a importância de ações para fortalecer a relação família-escola mudou?',['Sim, valorizo ainda mais','Mudou um pouco','Continuo pensando igual','Prefiro não responder']],
  ['Após a experiência, como você avalia o uso de recursos digitais para aproximação com as famílias?',['Muito positivo','Positivo em parte','Pouco eficaz','Prefiro não responder']],
  ['Como você percebe hoje o envolvimento das famílias no desenvolvimento das crianças?',['Melhorou bastante','Melhorou um pouco','Não percebi mudança','Prefiro não responder']],
  ['Você considera que escola e família devem atuar juntas no processo educativo após essa experiência?',['Sim, ainda mais que antes','Sim, continuo acreditando','Não percebi diferença','Prefiro não responder']]
 ], abertas:['Quais mudanças você percebeu na relação entre escola e famílias durante a pesquisa?','Na sua opinião, quais contribuições o ConectaPais trouxe para a instituição?','Deixe sua opinião, sugestão ou comentário final sobre a pesquisa.']}
};

function download(name, data){const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}); const url=URL.createObjectURL(blob); const a=document.createElement('a'); a.href=url; a.download=name; a.click(); URL.revokeObjectURL(url);}
function goGoogle(link){ if(link) window.open(link,'_blank'); else alert('Aqui você poderá colocar o link do Google Forms. Por enquanto o formulário interno do site está funcionando para teste.'); }

function App(){
 const [screen,setScreen]=useState('inicio'); const [grupo,setGrupo]=useState(null); const [li,setLi]=useState(false); const [resp,setResp]=useState({}); const [conteudo,setConteudo]=useState(null); const [duvida,setDuvida]=useState('');
 const dados=useMemo(()=> grupo==='equipe'?{nome:'Equipe pedagógica',tcle:TCLE.equipe,ini:'equipeInicial',fim:'equipeFinal',color:'azul'}:{nome:'Pais, mães ou responsáveis',tcle:TCLE.pais,ini:'paisInicial',fim:'paisFinal',color:'rosa'},[grupo]);
 const setR=(k,v)=>setResp(x=>({...x,[k]:v})); const reset=()=>{setScreen('inicio');setGrupo(null);setResp({});setLi(false);};
 const Form=({tipo,next})=>{const f=forms[tipo];return <main className="container"><section className="card wide"><h2>📝 {f.titulo}</h2><p className="muted">Não existem respostas certas ou erradas. Responda como se sentir à vontade.</p><label className="label">Código do participante</label><p className="hint">{f.codigo}</p><input className="input" value={resp[tipo+'_codigo']||''} onChange={e=>setR(tipo+'_codigo',e.target.value)} placeholder="Digite seu código"/>{f.objetivas.map(([q,ops],i)=><div className="question" key={q}><b>{i+1}. {q}</b><div className="options">{ops.map(op=><label key={op}><input type="radio" name={tipo+i} onChange={()=>setR(tipo+'_q'+i,op)} checked={resp[tipo+'_q'+i]===op}/> {op}</label>)}</div></div>)}{f.abertas.map((q,i)=><div className="question" key={q}><b>{f.objetivas.length+i+1}. {q}</b><textarea className="textarea" value={resp[tipo+'_aberta'+i]||''} onChange={e=>setR(tipo+'_aberta'+i,e.target.value)} placeholder="Escreva aqui..."/><label><input type="checkbox" onChange={e=>setR(tipo+'_aberta'+i,e.target.checked?'Prefiro não responder':'')}/> Prefiro não responder</label></div>)}<div className="row"><button onClick={next}>Enviar e continuar ➜</button><button className="outline" onClick={()=>download(tipo+'_respostas.json',{grupo,tipo,resp})}>Baixar respostas</button></div></section></main>}
 return <div><div className="bg"><span>🌻</span><span>🌈</span><span>☁️</span><span>🎨</span><span>🧸</span></div><header><div className="logo" onClick={reset}>💛 <div><b>ConectaPais</b><small>Laços Educativos entre Família e Escola</small></div></div><nav><span>⭐ Produto educacional</span><span>📅 70 dias</span><span>✨ Conteúdos semanais</span></nav></header>
 {screen==='inicio'&&<main className="container hero"><section><div className="pill">🌼 Bem-vindo(a) ao nosso espaço de aproximação</div><h1>ConectaPais: <span>família e escola mais perto</span></h1><p>Este site é o produto educacional da pesquisa de mestrado e foi criado para aproximar as famílias do {CONFIG.instituicao} do trabalho pedagógico desenvolvido na Educação Infantil.</p><div className="card"><h3>💛 Agradecimento inicial</h3><p>Agradeço de coração por você estar aqui. Sua participação é muito importante para esta pesquisa e para pensarmos, juntos, caminhos que fortaleçam a relação entre família e escola.</p></div></section><section className="choice"><button className="big pink" onClick={()=>{setGrupo('pais');setScreen('tcle')}}>👨‍👩‍👧 Pais, mães ou responsáveis<br/><small>Ler TCLE e iniciar</small></button><button className="big blue" onClick={()=>{setGrupo('equipe');setScreen('tcle')}}>🏫 Equipe pedagógica<br/><small>Ler TCLE e colaborar</small></button></section></main>}
 {screen==='tcle'&&<main className="container"><section className="card wide"><h2>📄 TCLE — {dados.nome}</h2><div className="notice"><b>Participação voluntária • Sigilo garantido • Liberdade para responder</b></div><p>{dados.tcle}</p><p><b>Pesquisador responsável:</b> {CONFIG.orientador}<br/><b>Pesquisadora assistente:</b> {CONFIG.pesquisadora}<br/><b>Contato:</b> {CONFIG.emailContato} — {CONFIG.telefoneContato}</p><p className="hint">Você poderá colar aqui o TCLE completo aprovado pelo CEP, se desejar.</p><label className="agree"><input type="checkbox" checked={li} onChange={e=>setLi(e.target.checked)}/> Declaro que li e compreendi as informações.</label><div className="row"><button disabled={!li} onClick={()=>setScreen('questionarioInicial')}>✅ Aceito participar</button><button className="danger" onClick={()=>setScreen('nao')}>❌ Não aceito participar</button></div></section></main>}
 {screen==='nao'&&<main className="container"><section className="card center"><h2>Participação encerrada</h2><p>Agradecemos por acessar o ConectaPais. Sua escolha será respeitada e não trará nenhum prejuízo.</p><button onClick={reset}>Voltar ao início</button></section></main>}
 {screen==='questionarioInicial'&&<Form tipo={dados.ini} next={()=>setScreen('principal')}/>} 
 {screen==='principal'&&<main className="container grid"><aside className="card"><h3>📚 Conteúdos anteriores</h3>{CONFIG.conteudosAnteriores.map(x=><p className="old" key={x}>{x}</p>)}<div className="tip">✏️ Para editar conteúdos, altere a área CONFIG no arquivo src/main.jsx.</div></aside><section><div className="banner"><h2>📖 Página principal</h2><p>Acompanhe os conteúdos do ConectaPais, envie dúvidas e participe.</p></div><div className="tags"><span>🌼 Educação Infantil</span><span>🎨 Aprender brincando</span><span>💛 Família e escola</span></div><div className="cards">{CONFIG.conteudosSemana.map((c,i)=><article className="content" key={c.titulo}><div className="emoji">{c.emoji}</div><small>{c.tipo}</small><h3>{c.titulo}</h3><p>{c.texto.slice(0,115)}...</p><button className="outline" onClick={()=>setConteudo(i)}>Abrir conteúdo</button></article>)}</div>{conteudo!==null&&<div className="card"><h2>{CONFIG.conteudosSemana[conteudo].emoji} {CONFIG.conteudosSemana[conteudo].titulo}</h2><p>{CONFIG.conteudosSemana[conteudo].texto}</p><button className="outline" onClick={()=>setConteudo(null)}>Fechar</button></div>}<div className="card"><h2>💬 Espaço para dúvidas</h2><textarea className="textarea" value={duvida} onChange={e=>setDuvida(e.target.value)} placeholder="Digite sua dúvida aqui..."/><button onClick={()=>{setR('duvida',duvida); alert('Dúvida registrada para teste. Para uso real, conecte ao Google Forms ou planilha.')}}>Enviar dúvida</button></div><button className="purple" onClick={()=>setScreen('reta')}>Abrir etapa final 🎉</button></section></main>}
 {screen==='reta'&&<main className="container"><section className="card center"><h1>🎉 Estamos na reta final!</h1><p>Para concluir sua participação, precisamos que você responda o questionário final.</p><button onClick={()=>setScreen('questionarioFinal')}>Responder questionário final</button></section></main>}
 {screen==='questionarioFinal'&&<Form tipo={dados.fim} next={()=>setScreen('enquete')}/>} 
 {screen==='enquete'&&<main className="container"><section className="card wide"><h2>📅 Enquete final</h2>{[['Você tem interesse em participar de um encontro presencial final sobre o ConectaPais?',['Sim, tenho interesse','Talvez','Não tenho interesse no momento','Prefiro não responder']],['O que mais motivaria sua participação nesse encontro?',['Conhecer os resultados da pesquisa','Tirar dúvidas e conversar','Compartilhar minha opinião','Prefiro não responder']]].map(([q,ops],i)=><div className="question" key={q}><b>{i+1}. {q}</b><div className="options">{ops.map(op=><label key={op}><input type="radio" name={'enq'+i} onChange={()=>setR('enquete'+i,op)}/> {op}</label>)}</div></div>)}<textarea className="textarea" placeholder="Deseja deixar alguma sugestão para esse encontro?" onChange={e=>setR('enquete_sugestao',e.target.value)}/><button onClick={()=>setScreen('final')}>Finalizar participação</button></section></main>}
 {screen==='final'&&<main className="container"><section className="card center"><h1>💖 Muito obrigada pela sua participação!</h1><p>Sua colaboração foi muito importante para o desenvolvimento desta pesquisa e para o uso do ConectaPais como material informativo de aproximação entre família e escola.</p><button onClick={()=>download('registro_conectapais.json',{grupo,resp,duvida})}>Baixar registro das respostas</button><button className="outline" onClick={reset}>Voltar ao início</button></section></main>}
 <footer>{CONFIG.nomeProduto} — Produto educacional vinculado à pesquisa de mestrado.</footer></div>
}

createRoot(document.getElementById('root')).render(<App/>);
