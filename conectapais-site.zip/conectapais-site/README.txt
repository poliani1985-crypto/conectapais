CONECTAPAIS - COMO PUBLICAR NO VERCEL

1. Entre no Vercel.
2. Clique em Add New / New Project.
3. Escolha a opção de importar/upload do projeto.
4. Envie esta pasta ou o arquivo ZIP.
5. Clique em Deploy.

COMO EDITAR
Abra o arquivo: src/main.jsx
Procure pela área: CONFIG
Ali você altera:
- nome do produto;
- conteúdos semanais;
- conteúdos anteriores;
- dados de contato;
- links dos Google Forms.

IMPORTANTE
Este modelo já tem fluxo, TCLE, questionários, conteúdos, dúvidas, etapa final e enquete.
Para coleta oficial das respostas, recomenda-se conectar os questionários ao Google Forms/Planilhas antes da aplicação.
